aplicacion.controller("InicioCtrl",function($scope){

    $scope.titulo = "INGRESO POKEMONES"

});
